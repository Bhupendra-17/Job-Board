const express = require("express");
const cors = require('cors');

const app = express();
app.use(cors());

app.get('/api/youtube', (req, res) => {
    res.json({ like: "Like the video", subscribe: "Subscribe the channel" });
})
const port = 4000;
app.listen(port, () => {
    console.log(`Server created and started running Port :${port}`);
}) 